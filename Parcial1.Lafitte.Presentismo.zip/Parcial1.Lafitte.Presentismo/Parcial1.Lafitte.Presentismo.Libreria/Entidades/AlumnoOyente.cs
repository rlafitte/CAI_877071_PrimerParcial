﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial1.Lafitte.Presentismo.Libreria.Entidades
{
    public class AlumnoOyente : Alumno
    {
        public AlumnoOyente(int i, string s1, string s2)
        {

        }
    }
}
